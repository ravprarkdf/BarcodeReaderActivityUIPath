﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel.Composition;
using Spire.Barcode;
using System.ComponentModel;
using System.Windows.Media;
using System.Drawing;


namespace BarcodeActivities
{
    class BarcodeGenerator:CodeActivity
    {

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> BarcodeValue { get; set; }

        [Category("Output")]
        public OutArgument<System.Drawing.Bitmap> Barcode { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string barcodeval = (BarcodeValue.Get(context)).ToString();
            Spire.Barcode.BarcodeSettings settings = new BarcodeSettings();
            settings.ShowText = true;
            settings.Data = barcodeval;
            settings.ShowTopText = false;
            Barcode.Set(context, new BarCodeGenerator(settings).GenerateImage());
         }
    }
}
